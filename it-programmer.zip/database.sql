/* create table my_client - run in your Postgres */
CREATE TABLE my_client (id serial primary key);
